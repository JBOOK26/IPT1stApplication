package com.example.a2;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard);

        // Get user email from intent
        String userEmail = getIntent().getStringExtra("USER_EMAIL");
        String userName = "Justin";

        // Initialize views
        TextView welcomeText = findViewById(R.id.textView3);
        welcomeText.setText(userName + "!"); // Simple concatenation for now

        ImageView homeButton = findViewById(R.id.imageView7);
        ImageView discoverButton = findViewById(R.id.imageView8);
        ImageView bookmarkButton = findViewById(R.id.imageView9);
        ImageView settingsButton = findViewById(R.id.imageView10);

        // Set up bottom navigation
        setupBottomNavigation(homeButton, discoverButton, bookmarkButton, settingsButton);

        // Handle back button with modern approach
        setupBackPressedHandler();
    }

    private void setupBottomNavigation(ImageView homeButton, ImageView discoverButton,
                                       ImageView bookmarkButton, ImageView settingsButton) {
        homeButton.setOnClickListener(v ->
                Toast.makeText(DashboardActivity.this, "Home", Toast.LENGTH_SHORT).show()
        );

        discoverButton.setOnClickListener(v ->
                Toast.makeText(DashboardActivity.this, "Discover", Toast.LENGTH_SHORT).show()
        );

        bookmarkButton.setOnClickListener(v ->
                Toast.makeText(DashboardActivity.this, "Bookmarks", Toast.LENGTH_SHORT).show()
        );

        settingsButton.setOnClickListener(v ->
                Toast.makeText(DashboardActivity.this, "Settings", Toast.LENGTH_SHORT).show()
        );
    }

    private void setupBackPressedHandler() {
        // Modern way to handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Handle back press
                finish();
            }
        });
    }
}