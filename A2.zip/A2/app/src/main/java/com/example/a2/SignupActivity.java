package com.example.a2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        // Initialize views
        EditText editTextName = findViewById(R.id.editTextText2);
        EditText editTextEmail = findViewById(R.id.editTextTextEmailAddress3);
        EditText editTextPassword = findViewById(R.id.editTextNumberPassword);
        EditText editTextConfirmPassword = findViewById(R.id.editTextNumberPassword2);
        Button signupButton = findViewById(R.id.button);

        signupButton.setOnClickListener(v -> registerUser(editTextName, editTextEmail, editTextPassword, editTextConfirmPassword));
    }

    private void registerUser(EditText editTextName, EditText editTextEmail, EditText editTextPassword, EditText editTextConfirmPassword) {
        String name = editTextName.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();

        // Validation
        if (name.isEmpty()) {
            editTextName.setError("Name is required");
            editTextName.requestFocus();
            return;
        }

        if (email.isEmpty()) {
            editTextEmail.setError("Email is required");
            editTextEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            editTextPassword.setError("Password is required");
            editTextPassword.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            editTextConfirmPassword.setError("Passwords do not match");
            editTextConfirmPassword.requestFocus();
            return;
        }

        // Registration logic would go here
        Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show();

        // Navigate back to login
        Intent intent = new Intent(SignupActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}